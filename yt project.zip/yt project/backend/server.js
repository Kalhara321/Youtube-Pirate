const express = require('express');
const cors = require('cors');
const ytdl = require('@distube/ytdl-core');
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');


const app = express();
const PORT = 5000;

// Middleware
app.use(cors());
app.use(express.json());

// Create downloads folder if it doesn't exist
const downloadsDir = path.join(__dirname, 'downloads');
if (!fs.existsSync(downloadsDir)) {
    fs.mkdirSync(downloadsDir);
    console.log('📁 Created downloads folder:', downloadsDir);
}

// Download endpoint
app.post('/api/download', async (req, res) => {
    const { url, format, quality } = req.body;

    console.log('\n========================================');
    console.log('📥 NEW DOWNLOAD REQUEST');
    console.log('URL:', url);
    console.log('Format:', format);
    console.log('Quality:', quality);
    console.log('Time:', new Date().toLocaleTimeString());
    console.log('========================================');

    try {
        // Validate YouTube URL
        if (!ytdl.validateURL(url)) {
            console.log('❌ VALIDATION FAILED: Invalid YouTube URL');
            return res.status(400).json({ 
                success: false, 
                message: 'Invalid YouTube URL' 
            });
        }

        console.log('✅ URL validation passed');
        console.log('🔍 Fetching video info from YouTube...');

        // Get video info
        const info = await ytdl.getInfo(url);
        console.log('✅ Video info retrieved successfully');
        
        const videoTitle = info.videoDetails.title
            .replace(/[^a-zA-Z0-9\s-]/g, '')
            .replace(/\s+/g, '_')
            .substring(0, 50);
        
        console.log('📹 Original Title:', info.videoDetails.title);
        console.log('📝 Cleaned Title:', videoTitle);
        console.log('👤 Channel:', info.videoDetails.author.name);

        if (format === 'video') {
            // ============ VIDEO DOWNLOAD ============
            const filename = `${videoTitle}_video.mp4`;
            const outputPath = path.join(downloadsDir, filename);
            
            console.log('\n🎥 === VIDEO DOWNLOAD MODE ===');
            console.log('📁 Full path:', outputPath);
            console.log('🚀 Starting video download...');

            const stream = ytdl(url, { 
                filter: 'videoandaudio',
                quality: 'highest'
            });

            const writeStream = fs.createWriteStream(outputPath);
            stream.pipe(writeStream);

            let hasResponded = false;

            writeStream.on('finish', () => {
                if (!hasResponded) {
                    hasResponded = true;
                    console.log('✅ VIDEO SAVED SUCCESSFULLY!');
                    console.log('📁 File location:', outputPath);
                    console.log('📊 File size:', (fs.statSync(outputPath).size / 1024 / 1024).toFixed(2), 'MB');
                    
                    res.json({ 
                        success: true, 
                        message: 'Video download completed!',
                        filename: filename
                    });
                }
            });

            stream.on('error', (error) => {
                if (!hasResponded) {
                    hasResponded = true;
                    console.error('❌ VIDEO ERROR:', error.message);
                    res.status(500).json({ 
                        success: false, 
                        message: error.message
                    });
                }
            });

        } else {
            // ============ AUDIO DOWNLOAD ============
            const filename = `${videoTitle}_audio.webm`;
            const outputPath = path.join(downloadsDir, filename);
            
            console.log('\n🎵 === AUDIO DOWNLOAD MODE ===');
            console.log('📁 Full path:', outputPath);
            console.log('🔍 Checking available audio formats...');

            // Check available audio formats
            const audioFormats = ytdl.filterFormats(info.formats, 'audioonly');
            console.log('📊 Found', audioFormats.length, 'audio formats');
            
            if (audioFormats.length > 0) {
                console.log('🎧 Best audio format:', audioFormats[0].container, '-', audioFormats[0].audioBitrate + 'kbps');
            }

            console.log('🚀 Starting audio download...');

            const stream = ytdl(url, { 
                filter: 'audioonly',
                quality: 'highestaudio'
            });

            const writeStream = fs.createWriteStream(outputPath);
            
            let hasResponded = false;
            let bytesWritten = 0;

            stream.on('data', (chunk) => {
                bytesWritten += chunk.length;
                process.stdout.write(`\r📥 Downloading: ${(bytesWritten / 1024 / 1024).toFixed(2)} MB`);
            });

            stream.pipe(writeStream);

            writeStream.on('finish', () => {
                console.log('\n🎉 WRITE STREAM FINISHED!');
                
                // Double check file exists
                if (fs.existsSync(outputPath)) {
                    const fileSize = fs.statSync(outputPath).size;
                    console.log('✅ FILE EXISTS!');
                    console.log('📁 File location:', outputPath);
                    console.log('📊 File size:', (fileSize / 1024 / 1024).toFixed(2), 'MB');
                    console.log('🎵 Format: .webm (plays in VLC, Media Player, etc.)');
                    
                    if (!hasResponded) {
                        hasResponded = true;
                        res.json({ 
                            success: true, 
                            message: 'Audio download completed!',
                            filename: filename,
                            fileSize: fileSize,
                            path: outputPath
                        });
                    }
                } else {
                    console.log('❌ FILE DOES NOT EXIST AFTER WRITE!');
                    if (!hasResponded) {
                        hasResponded = true;
                        res.status(500).json({ 
                            success: false, 
                            message: 'File was not created'
                        });
                    }
                }
            });

            stream.on('error', (error) => {
                console.error('\n❌ AUDIO STREAM ERROR:', error.message);
                console.error('Error details:', error);
                
                if (!hasResponded) {
                    hasResponded = true;
                    res.status(500).json({ 
                        success: false, 
                        message: 'Audio download failed: ' + error.message
                    });
                }
            });

            writeStream.on('error', (error) => {
                console.error('\n❌ WRITE STREAM ERROR:', error.message);
                console.error('Error details:', error);
                
                if (!hasResponded) {
                    hasResponded = true;
                    res.status(500).json({ 
                        success: false, 
                        message: 'File write failed: ' + error.message
                    });
                }
            });

            // Timeout after 2 minutes
            setTimeout(() => {
                if (!hasResponded) {
                    hasResponded = true;
                    console.log('⏱️  TIMEOUT: Download took too long');
                    res.status(500).json({ 
                        success: false, 
                        message: 'Download timeout'
                    });
                }
            }, 120000); // 2 minutes
        }

    } catch (error) {
        console.error('\n❌ CATCH ERROR:', error.message);
        console.error('Error type:', error.name);
        console.error('Stack:', error.stack);
        
        res.status(500).json({ 
            success: false, 
            message: 'Server error: ' + error.message
        });
    }
});

// Test endpoint
app.get('/api/test', (req, res) => {
    console.log('🧪 Test endpoint hit');
    res.json({ 
        message: 'Backend is working!',
        downloadsFolder: downloadsDir,
        time: new Date().toISOString()
    });
});

// List downloads endpoint (to check what's in the folder)
app.get('/api/downloads', (req, res) => {
    try {
        const files = fs.readdirSync(downloadsDir);
        console.log('📂 Files in downloads folder:', files.length);
        
        const fileDetails = files.map(file => {
            const filePath = path.join(downloadsDir, file);
            const stats = fs.statSync(filePath);
            return {
                name: file,
                size: (stats.size / 1024 / 1024).toFixed(2) + ' MB',
                created: stats.birthtime
            };
        });
        
        res.json({
            success: true,
            count: files.length,
            files: fileDetails
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
});

app.listen(PORT, () => {
    console.log('\n🚀 ========================================');
    console.log('✅ YouTube Downloader Backend');
    console.log('🌐 Server: http://localhost:' + PORT);
    console.log('📁 Downloads: ' + downloadsDir);
    console.log('========================================\n');
});