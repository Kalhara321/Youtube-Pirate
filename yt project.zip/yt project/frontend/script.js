// Main Application
class YouTubeDownloader {
    constructor() {
        this.selectedFormat = 'video';
        this.selectedQuality = '720p';
        this.videoQualities = ['144p', '240p', '360p', '480p', '720p', '1080p', '1440p', '2160p'];
        this.audioQualities = ['64kbps', '128kbps', '192kbps', '256kbps', '320kbps'];
        
        this.initializeElements();
        this.setupEventListeners();
        this.loadHistory();
        this.updateQualityButtons();
    }

    initializeElements() {
        // Input elements
        this.urlInput = document.getElementById('urlInput');
        this.pasteBtn = document.getElementById('pasteBtn');
        this.downloadBtn = document.getElementById('downloadBtn');
        
        // Format selection
        this.videoFormatBtn = document.getElementById('videoFormat');
        this.audioFormatBtn = document.getElementById('audioFormat');
        this.qualityButtons = document.getElementById('qualityButtons');
        
        // Options checkboxes
        this.subtitlesOption = document.getElementById('subtitlesOption');
        this.metadataOption = document.getElementById('metadataOption');
        this.thumbnailOption = document.getElementById('thumbnailOption');
        
        // UI sections
        this.loading = document.getElementById('loading');
        this.errorMessage = document.getElementById('errorMessage');
        this.errorText = document.getElementById('errorText');
        this.videoInfoSection = document.getElementById('videoInfoSection');
        this.thumbnailPlaceholder = document.getElementById('thumbnailPlaceholder');
        
        // Video info elements
        this.videoTitle = document.getElementById('videoTitle');
        this.videoDuration = document.getElementById('videoDuration');
        this.videoChannel = document.getElementById('videoChannel');
        
        // History elements
        this.historyList = document.getElementById('historyList');
        this.clearHistoryBtn = document.getElementById('clearHistoryBtn');
    }

    setupEventListeners() {
        // Paste button
        this.pasteBtn.addEventListener('click', () => this.handlePaste());
        
        // Download button
        this.downloadBtn.addEventListener('click', () => this.handleDownload());
        
        // Format selection
        this.videoFormatBtn.addEventListener('click', () => this.selectFormat('video'));
        this.audioFormatBtn.addEventListener('click', () => this.selectFormat('audio'));
        
        // Input events
        this.urlInput.addEventListener('input', () => this.validateURL());
        this.urlInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.handleDownload();
        });
        
        // Clear history
        this.clearHistoryBtn.addEventListener('click', () => this.clearHistory());
    }

    selectFormat(format) {
        this.selectedFormat = format;
        
        // Update UI
        if (format === 'video') {
            this.videoFormatBtn.classList.add('active');
            this.audioFormatBtn.classList.remove('active');
        } else {
            this.audioFormatBtn.classList.add('active');
            this.videoFormatBtn.classList.remove('active');
        }
        
        // Update quality buttons
        this.updateQualityButtons();
    }

    updateQualityButtons() {
        this.qualityButtons.innerHTML = '';
        const qualities = this.selectedFormat === 'video' ? this.videoQualities : this.audioQualities;
        
        qualities.forEach(quality => {
            const btn = document.createElement('button');
            btn.className = 'quality-btn';
            btn.textContent = quality;
            
            // Set default active quality
            if ((this.selectedFormat === 'video' && quality === '720p') || 
                (this.selectedFormat === 'audio' && quality === '128kbps')) {
                btn.classList.add('active');
                this.selectedQuality = quality;
            }
            
            btn.addEventListener('click', () => this.selectQuality(quality, btn));
            this.qualityButtons.appendChild(btn);
        });
    }

    selectQuality(quality, button) {
        // Remove active class from all buttons
        document.querySelectorAll('.quality-btn').forEach(btn => btn.classList.remove('active'));
        
        // Add active class to clicked button
        button.classList.add('active');
        this.selectedQuality = quality;
    }

    async handlePaste() {
        try {
            const text = await navigator.clipboard.readText();
            this.urlInput.value = text;
            this.validateURL();
        } catch (err) {
            console.error('Failed to paste:', err);
            this.showError('Clipboard access denied. Please paste manually.');
        }
    }

    validateURL() {
        const url = this.urlInput.value.trim();
        
        if (!url) {
            this.hideVideoInfo();
            this.hideError();
            return false;
        }
        
        const isValid = this.isValidYouTubeURL(url);
        
        if (!isValid) {
            this.showError('Please enter a valid YouTube URL');
            this.hideVideoInfo();
            return false;
        }
        
        this.hideError();
        return true;
    }

    isValidYouTubeURL(url) {
        const patterns = [
            /^(https?:\/\/)?(www\.)?youtube\.com\/watch\?v=[\w-]{11}/,
            /^(https?:\/\/)?(www\.)?youtu\.be\/[\w-]{11}/,
            /^(https?:\/\/)?(www\.)?youtube\.com\/embed\/[\w-]{11}/,
            /^(https?:\/\/)?(www\.)?youtube\.com\/v\/[\w-]{11}/,
            /^(https?:\/\/)?(www\.)?youtube\.com\/shorts\/[\w-]{11}/
        ];
        
        return patterns.some(pattern => pattern.test(url));
    }

async handleDownload() {
    const url = this.urlInput.value.trim();

    if (!this.validateURL()) return;

    this.showLoading();

    try {
        const response = await fetch("http://localhost:5000/api/download", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                url: url,
                format: this.selectedFormat,
                quality: this.selectedQuality
            })
        });

        const data = await response.json();

        if (!data.success) throw new Error();

        alert("✅ Download finished! Check backend/downloads folder");

} catch (err) {
    console.error(err); // Add this to see the actual error in Browser Console
    this.showError("Download failed. Check backend terminal.");
} finally {
        this.hideLoading();
    }
}




    extractVideoId(url) {
        const patterns = [
            /v=([\w-]{11})/,
            /youtu\.be\/([\w-]{11})/,
            /embed\/([\w-]{11})/,
            /v\/([\w-]{11})/,
            /shorts\/([\w-]{11})/
        ];
        
        for (const pattern of patterns) {
            const match = url.match(pattern);
            if (match) return match[1];
        }
        
        return null;
    }

    getDownloadOptions() {
        return {
            subtitles: this.subtitlesOption.checked,
            metadata: this.metadataOption.checked,
            thumbnail: this.thumbnailOption.checked
        };
    }

    simulateProcessing() {
        return new Promise(resolve => {
            setTimeout(() => {
                // Simulate video info fetching
                const videoId = this.extractVideoId(this.urlInput.value);
                if (videoId) {
                    this.showVideoInfo(videoId);
                }
                resolve();
            }, 1500);
        });
    }

    showVideoInfo(videoId) {
        this.videoInfoSection.classList.add('active');
        
        // Update placeholder with video ID
        this.thumbnailPlaceholder.innerHTML = `
            <div class="video-id">${videoId}</div>
            <i class="fab fa-youtube"></i>
            <span>YouTube Video</span>
        `;
        
        // Set video info
        this.videoTitle.textContent = `Video: ${videoId}`;
        this.videoDuration.textContent = 'Processing...';
        this.videoChannel.textContent = 'YouTube';
    }

    showVideoInfoWithData(data) {
        this.videoInfoSection.classList.add('active');
        
        if (data.thumbnail) {
            this.thumbnailPlaceholder.style.backgroundImage = `url(${data.thumbnail})`;
            this.thumbnailPlaceholder.innerHTML = '';
        }
        
        this.videoTitle.textContent = data.title || 'YouTube Video';
        this.videoDuration.textContent = data.duration || 'Unknown duration';
        this.videoChannel.textContent = data.channel || 'YouTube Channel';
    }

    hideVideoInfo() {
        this.videoInfoSection.classList.remove('active');
    }

    showLoading() {
        this.loading.classList.add('active');
        this.hideError();
    }

    hideLoading() {
        this.loading.classList.remove('active');
    }

    showError(message) {
        this.errorText.textContent = message;
        this.errorMessage.classList.add('active');
    }

    hideError() {
        this.errorMessage.classList.remove('active');
    }

    showSuccessMessage(downloadEntry) {
        const formatText = downloadEntry.format === 'video' ? 'Video' : 'Audio';
        const qualityText = downloadEntry.quality;
        
        const message = `✅ ${formatText} (${qualityText}) download prepared!\n\nClick "OK" to start downloading.`;
        
        // Show confirmation
        if (confirm(message)) {
            // In a real implementation, this would trigger the actual download
            console.log('Starting download:', downloadEntry);
            this.initiateDownload(downloadEntry);
        }
    }

    initiateDownload(downloadEntry) {
        // This is where you would implement the actual download logic
        // For example, using a backend API or a download service
        
        console.log('Download initiated:', downloadEntry);
        
        // For demo purposes, we'll show a message
        alert(`Downloading ${downloadEntry.format} in ${downloadEntry.quality} quality...\n\nThis would start the actual download in a real implementation.`);
    }

    saveToHistory(downloadEntry) {
        let history = this.getHistory();
        history.unshift(downloadEntry);
        
        // Keep only last 10 items
        if (history.length > 10) {
            history = history.slice(0, 10);
        }
        
        localStorage.setItem('youtubeDownloaderHistory', JSON.stringify(history));
        this.updateHistoryDisplay();
    }

    getHistory() {
        const history = localStorage.getItem('youtubeDownloaderHistory');
        return history ? JSON.parse(history) : [];
    }

    loadHistory() {
        this.updateHistoryDisplay();
    }

    updateHistoryDisplay() {
        const history = this.getHistory();
        
        if (history.length === 0) {
            this.historyList.innerHTML = '<div class="empty-history">No downloads yet</div>';
            return;
        }
        
        this.historyList.innerHTML = '';
        
        history.forEach(entry => {
            const item = document.createElement('div');
            item.className = 'history-item';
            item.innerHTML = `
                <div class="history-item-info">
                    <div class="history-item-title">${entry.title}</div>
                    <div class="history-item-details">
                        <span class="history-item-format">${entry.format} (${entry.quality})</span>
                        <span>${new Date(entry.timestamp).toLocaleDateString()}</span>
                    </div>
                </div>
            `;
            
            this.historyList.appendChild(item);
        });
    }

    clearHistory() {
        if (confirm('Are you sure you want to clear all download history?')) {
            localStorage.removeItem('youtubeDownloaderHistory');
            this.updateHistoryDisplay();
        }
    }
}

// Initialize the application when the page loads
document.addEventListener('DOMContentLoaded', () => {
    const downloader = new YouTubeDownloader();
    
    // Make downloader available globally for debugging (optional)
    window.downloader = downloader;
});

const themeToggle = document.getElementById("themeToggle");

themeToggle.addEventListener("click", () => {
    document.body.classList.toggle("dark");

    themeToggle.innerHTML = document.body.classList.contains("dark")
        ? '<i class="fas fa-sun"></i>'
        : '<i class="fas fa-moon"></i>';
});
